#ifndef __SERVO_H
#define __SERVO_H

void Servo_Init(void);
void Servo_Angle1(float Angle);
void Servo_Angle2(float Angle);
void Servo_Angle3(float Angle);
void Servo_Angle4(float Angle);
void WServo_Angle(float Angle);

#endif

