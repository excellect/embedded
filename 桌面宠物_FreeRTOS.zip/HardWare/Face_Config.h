#ifndef __FACE_CONFIG_
#define __FACE_CONFIG_

void Face_Config(void);

#endif
