#ifndef __PET_ACTION_
#define __PET_ACTION

void Action_relaxed_getdowm(void);
void Action_upright(void);
void Action_getdowm(void);
void Action_sit(void);
void Action_Swing(void);
void Action_advance(void);
void Action_back(void);
void Action_Lrotation(void);
void Action_Rrotation(void);
void Action_SwingTail(void);//摇尾巴
void Action_JumpD(void);//向后跳
void Action_JumpU(void);//向前跳
void Action_upright2(void);//动作辅助
void Action_Hello(void);//打招呼

#endif
